<?php
echo md5('jamie123');

?>