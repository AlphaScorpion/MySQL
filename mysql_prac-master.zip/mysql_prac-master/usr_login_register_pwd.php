<?php
echo md5('pass123');


?>